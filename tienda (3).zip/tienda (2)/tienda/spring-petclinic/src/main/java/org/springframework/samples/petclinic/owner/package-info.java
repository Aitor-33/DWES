@NullMarked
package org.springframework.samples.petclinic.owner;

import org.jspecify.annotations.NullMarked;
