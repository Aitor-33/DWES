package com.example.examen.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.examen.entity.Arbitros;
import com.example.examen.entity.Equipos;

public interface EquiposRepository extends JpaRepository<Equipos, Long>{

}
