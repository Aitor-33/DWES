package com.example.examen;

public enum Rol {

    PRINCIPAL, ASISTENTE
}
