package com.example.examen;

public enum Posicion {

    PORTERO, DEFENSA, MEDIO, DELANTERO

}
