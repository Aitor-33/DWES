package com.example.simmanytoone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimmanytooneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimmanytooneApplication.class, args);
	}

}
